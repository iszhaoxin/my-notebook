## Chapter 3 Probability and Information Theory



### 3.1 Why Probability?

#### 1. some basic concepts

-   use it in two major ways:
    -   First, the laws of probability tell us how AI systems should reason.we can use probability theory to derive various expression which we need in AI system.(设计系统)
    -   Second, we can use probability and statistics to theoretically analyze the behavior of proposed AI systems.（检验系统）

-   概率论让我们去理解不确定性,信息论使我们去定量分析不确定性.

-   三种不确定性的来源

    -   Inherent stochasticity in the system being modeled.(固有的随机性)
    -   Incomplete observability.(不完整的可观察性)(we cannot observe all the variables that drive the behavior of the system.)
    -   Incomplete modeling(模型的不完整性),若是模型建立的不够合理,会产生不确定性.

-   在人为的系统中,不确定性有时要比一个确定系统更加有效

    ​

#### 2. Bayesian  VS frequentist 
- 解释1-理论层面
  频率学派与贝叶斯学派探讨「不确定性」这件事时的出发点与立足点不同.

  频率学派出发点为**[事件本身是随机的]**,立足于**[无限次的实验]**,对**[事件的随机性]**进行建模.
  贝叶斯学派出发点为**[观察者本身的知识不足]**,立足于**[先验知识]**,对**[基于先验知识的推理系统]**进行建模

|      | Bayesian probability | frequentist probability |
| :--- | :------------------- | :---------------------- |
| 出发点  | 事件本身是随机的             | 观察者本身的知识不足              |
| 立足点  | 无限次的实验               | 先验知识                    |
| 建模方法 | 事件的随机性               | 基于先验知识的推理系统             |

-   解释2-数学层面

    贝叶斯观点与频率观点其本质区别在于：

    贝叶斯学派认为参数是变量，而频率学派认为参数是定常的，只是我们不知道其取值而已.

-   更加详细的解释见,[Bayesian  VS frequentist]



### 3.2 Random Variables



### 3.3 Probability Distributions

**3.3.1 Discrete Variables and Probability Mass Functions**

**离散变量和概率质量函数**

-   一般用概率质量函数去描述离散变量的概率分布.

**3.3.2 Continuous Variables and Probability Density Functions**

连续变量和概率密度函数

-   一般用概率密度函数去描述连续变量的概率分布.
    ​

### 3.4 Marginal Probability

边缘概率就是指一个变量单独的概率.

对于离散变量而言:

$p(x) = \sum_yp(x,y)$

对于连续变量而言

$p(x)=\int p(x,y)dy$


### 3.5 Conditional Probability



### 3.6 The Chain Rule of Conditional Probabilities

想象n-gram的理论基础公式

![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/7.png)

###　3.7 Independence and Conditional Independence
** 独立性以及有条件的独立性**
- 独立性:$x\perp y$ : $p(x,y) = p(x) * p(y)$
- 有条件的独立性:$x \perp y | z$ : $p(x,y|z)=p(x|z)*p(y|z)$




### 3.8 Expectation, Variance and Covariance
#### Expectation
期望
#### Variance
方差
standard deviation = $\sqrt (variance)$

#### Covariance

-   The covariance gives some sense of how much two values are linearly related to each other, as well as the scale of these variables.:

    ​	$Cov(f(x),g(y))=E[(f(x)-E[f(x)])(g(y)-E[g(y)])]$

-   独立和相关系数有关系,但不是一个概念.

    -   如果说,两个变量之间非线性独立,那么其相关系数定不为0

    -   若,两个变量之间相关系数为0,只能说明其非线性相关,有可能有其他的相关关系.

        例如,$x\in [-1,1]$遵从均匀分布,$=s-1,1$,概率均为0.5,设$y=sx$:

        则,$Cov(x,y)=0$,但是明显两者具有依赖关系.

-   covariance matrix:相关系数矩阵

    ​		$Cov(x)_{i,j} = Cov(x_i,x_j)$



### 3.9 Common Probability Distributions

**常见的概率分布**

#### 1. Bernoulli Distribution

**伯努利分布** 非0即1,下面是该分布的一些性质:

![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/8.png)

#### 2. Multinoulli Distribution

该分布是伯努利分布的进阶版,变量有k个,分别为$[x_1,x_2,...,x_k]$.

只有一个的值为1,假设这k个变量的概率分布放在一个向量p里面.p的形式为						

​						$[0,0,...,1,...,0]^T$

则,k个变量的联合概率可以表示为:

![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/9.png)



这里对上面的公式进行解释:

![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/10.png)

也就是说,这个累乘看似复杂,不过因为其中$0^0=1$,因此就是指出了总概率和.

相关系数如下,不解释了,自己看着都费劲:

![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/11.png)

#### 3. Gaussian Distribution

-   大名鼎鼎的高斯分布

    下面是公式:

    ![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/12.png)
    但是在平时的计算中,若经常替换参数以评价PDF的质量,因此简化为以下的公式.

    ![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/13.png)

- 有时,在缺少先验知识但需要对某个参数或者变量的分布进行模拟时,都会采用高斯分布.原因如下

    - First, many distributions we wish to model are truly close to being normal distributions.central limit theorem(中心极限定理)shows that the sum of many independent random variables is approximately normally distributed.

        就是说中心极限定理证明了,各种独立的随机变量的分布之和接近于正态分布(即高斯分布)

    -   在所有拥有相同方差的分布中,正态分布有最大的不确定性,因此,**使用正态分布可以认为是对模拟的变量设置了最少的先验知识(本身就没有一点的先验知识)**,证明方法见19.4.2.

-   将高斯分布推广到高维空间,得到:

    ​				![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/14.png)
    其中

    ​	$\sum$是相关系数矩阵.

    如同在单变量下一样,可以对公式进行简化,可以用精度矩阵$\beta$代替$\sum$:

    ![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/15.png)

    我们经常会把相关系数矩阵转为一个对角矩阵.

    An even simplerversion is theisotropicGaussian distribution, whose covariance matrix is a scalartimes the identity matrix.(这个就不细追究了)

#### 4. Exponential and Laplace Distributions

-   指数分布

    ​				$p(x;\lambda )=(\lambda 1_{x\ge 0}) ^{-\lambda x}$		
    其中			$1_{x\ge 0} = 1$  $if$ $ x \ge 0$

-   Laplace distribution

    拉普拉斯分布就是两个指数分布背靠背的形状.公式为

    ​				$Laplace(x; µ, γ) =\frac{1}{2γ} exp(\frac{−|x − µ|}{γ})$

    形状是:

    ![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/16.png)fen
    拉普拉斯分布用于:声音辨识和JPEG图像压缩

#### 5. Dirac distribution and empirical distribution 

-   **狄拉克分布**:all the mass in the probability distribution clusters around a single point

    ​							$p(x) = δ(x −µ).$

-   Dirac分布不是一个用于描述真是数据的分布函数,而是作为一种用于数学分析的广义函数.

-   Dirac分布被用于**empirical distribution**的一个组成部分.经验分布函数是在n个数据点中的每一个上都跳跃1 / n的阶梯函数。 其在测量变量的任何指定值处的值是小于或等于指定值的测量变量的观测值的数。Dirac分布在其中的作用相当于一个把连续函数变成一个离散函数的作用.

  -   In statistics, an empirical distribution function is the distribution function associated with the empirical measure of a sample. This cumulative distribution function is a step function that jumps up by 1/n at each of the n data points.经验分布不是一个拥有固定形状的分布,这个要依靠数据集的特性.这个函数的特点是,将数据集中的数据顺序排列,每到下一个数据点,该数据点对应的y值上升1/n.公式如下.对被测变量的某个值而言，该值的分布函数值表示所有观测样本中小于或等于该值的样本所占的比例。	



![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/17.png)

-   最后 empirical distribution的值趋近于零.分布图如下,其中经验分布函数 Fn(x) 的图形（如下图所示）是一条呈跳跃上升的阶梯形曲线.若数据量趋近于无限大,那么圆滑曲线是总体 X 的理论分布函数 F(x) 的图形.

    ![](/home/dreamer/files/algorithm/DL/DeepLearning textbook/pictures/18.png)

#### 6. Mixtures of Distributions

混合分布**

-   A distribution is made up of several component distributions.On each trial, the choice of which component distribution should generate the sample is determined by sampling a component identity from a multinoulli distribution.

    也就是说,哪一部分的样本应该遵从什么分布,这个可以由下面这个公式去标识,注意,是标识,不是判断.

    ​					$P(x) = \sum_i P(c=i)P(x|c=i)$

    就是说,$P(c=i)$是说分布为i的概率,$P(x|c=i)$是说,在分布为i的情况下,x的概率,也等同于上面说到的multinoulli 分布.

-   想想看,刚才我们是不是已经见过一个混合分布了?对!!!!,你没有猜错,去吧,拉普拉斯分布,就决定是你了(甩帽).在第16章,我们会讨论从简单的概率分布构建复杂概率分布的艺术!艺术,就是构建分布!!

-   混合模型牵扯到一个非常重要的概念--潜在变量,我在这里的理解是,潜在变量是不能直接观测到的变量,那么什么是可以直接观测到的变量呢?因为,在分析数据概率分布的时候,人们需要去假定该数据符合某种分布,所有说,首先这个模型就被确定了,在这个假定模型上的参数变量,我认为就是直接变量.即,**由确定模型和确定数据确定的变量**

    而潜在变量是指,影响模型决定的变量,和上面的不一样,以上面的公式举例,

    ​					$P(x) = \sum_i P(c=i)P(x|c=i)$

    这里的c就是那个潜在变量,$P(c=i)$是说分布为i的概率,即决定模型的变量,而在这个公式中,直接变量被隐藏在 $i$ 中,没有写出来.详细的内容见16.5

-   这里举了一个混合高斯的例子,今天早上还刚想过这个,应用在我构想的动词向量网络中,与动词共现的每个名词便可以作为混合高斯中每个高斯的均值.具体的算法细节参见还没有写的PRML笔记.:smirk:

    混合高斯模型可以认为是一个空间密度的通用逼真器.理论上,只要是平滑分布的密度,只要有足够多的子高斯分布,混合高斯可以零差错的描述任何空间密度分布.

-   这里还有必要介绍,三种不同类型的协方差矩阵所控制的高维高斯分布的特性.

    -   首先要清楚,这个部分要研究的是什么?

        我们平时的最简单的高斯分布,就是正态分布是一个一维分布,也就是说,只有一个变化方向,但是在高维中便不同,n维高斯分布控制的密度变化方向有n个,那数据的密度向哪个方向伸展,这个决定因素就在高维高斯分布的协方差矩阵中体现.再具体介绍各个矩阵之前,回顾一下协方差矩阵的性质,矩阵的中 $x_{i,j}$ 代表的是第i个因子和第j个因子的相关性,那么这里的因子便可以类别为维度信息.

    -   第一个类型: isotropic covariance matrix,各项同性协方差矩阵

        -   顾名思义,这个协方差矩阵控制下的分布,具有各维度均衡发展的特性,那什么是 isotropic covariance matrix呢?

        -   covariance matrix的特性为:

            ​		$C = \lambda I$

            即,这是一个单位矩阵,单位矩阵有什么特性呢?对单位矩阵进行坐标系转换,仍然是单位矩阵.

    -   第二个类型:diagonal covariance matrix,对角矩阵

        -   考虑刚才说到的协方差矩阵的本质,可以知道,这是一个,维度与维度之间互不干扰的分布,即每个维度之间是独立的,那么若设其中一些对角元素为0,便可以使数据朝一些维度集中.

    -   第三个类型:a full-rank covariance matrix,满秩协方差矩阵

        -   即,每个维度上都有分部信息,互相之间也许有干扰也许没干扰,这种矩阵也是最常出现最复杂的矩阵,可以控制各个方向的分布.



###　3.10 Useful Properties of Common Functions

**介绍了一些在处理概率分布时,通常用到的函数,特别是在深度学习中**

-   逻辑sigmoid

    ​					$σ(x) =\frac{1}{1 + exp(−x)}$

    ​	